import myMath

pertambahan = myMath.tambah(5, 3)
print(pertambahan)

pengurangan = myMath.kurang(12, 7)
print(pengurangan)

perkalian = myMath.kali(2, 3)
print(perkalian)

pembagian = myMath.bagi(10, 5)
print(pembagian)

sisa_bagi = myMath.modulus(12, 7)
print(sisa_bagi)

fibonacci = myMath.fibonacci(5)
print(fibonacci)